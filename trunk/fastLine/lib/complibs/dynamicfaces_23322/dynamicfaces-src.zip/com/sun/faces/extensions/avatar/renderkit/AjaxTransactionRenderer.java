/*
 * $Id: AjaxTransactionRenderer.java,v 1.1 2007/04/24 12:02:40 mb151649 Exp $
 */

/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the License). You may not use this file except in
 * compliance with the License.
 *
 * You can obtain a copy of the License at
 * https://javaserverfaces.dev.java.net/CDDL.html or
 * legal/CDDLv1.0.txt.
 * See the License for the specific language governing
 * permission and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * Header Notice in each file and include the License file
 * at legal/CDDLv1.0.txt.
 * If applicable, add the following below the CDDL Header,
 * with the fields enclosed by brackets [] replaced by
 * your own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 *
 * [Name of File] [ver.__] [Date]
 *
 * Copyright 2005 Sun Microsystems Inc. All Rights Reserved
 */

package com.sun.faces.extensions.avatar.renderkit;

import com.sun.faces.extensions.avatar.components.AjaxTransaction;
import com.sun.faces.extensions.avatar.components.ScriptsComponent;
import com.sun.faces.extensions.avatar.lifecycle.AsyncResponse;
import java.beans.Beans;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.el.ValueExpression;
import javax.faces.component.NamingContainer;

import javax.faces.component.UIComponent;
import javax.faces.component.UIData;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import javax.faces.render.Renderer;
import org.apache.shale.remoting.Mechanism;
import org.apache.shale.remoting.XhtmlHelper;

/**
 * This class renderers AjaxTransaction components.
 */
public class AjaxTransactionRenderer extends Renderer {
    
    private static final String scriptId = "/META-INF/com_sun_faces_ajax_tx.js"; //NOI18N
    
    /**
     * Render the beginning of the specified UIComponent to the output stream or
     * writer associated with the response we are creating.
     *
     * @param context FacesContext for the current request.
     * @param component UIComponent to be rendered.
     *
     * @exception IOException if an input/output error occurs.
     * @exception NullPointerException if context or component is null.
     */
    public void encodeBegin(FacesContext context, UIComponent component)
            throws IOException {
        if (context == null || component == null) {
            throw new NullPointerException();
        }

        if (Beans.isDesignTime() || !component.isRendered() || AsyncResponse.isAjaxRequest()) {
            return;
        }

        new ScriptsComponent().encodeAll(context);

        ResponseWriter writer = context.getResponseWriter();
        Map<String,Object> requestMap = context.getExternalContext().getRequestMap();
        if (!requestMap.containsKey(AjaxTransaction.TX_JS_LINKED)) {
            getXhtmlHelper().linkJavascript(context, component, writer,
                Mechanism.CLASS_RESOURCE, scriptId);
            requestMap.put(AjaxTransaction.TX_JS_LINKED, Boolean.TRUE);
        }
        
        /*
        UIComponent arb1 = find(context.getViewRoot(), "arbitrary1");
        UIComponent arb2 = find(context.getViewRoot(), "arbitrary2");
        UIComponent[] arbs = {arb1, arb2};
        for (int i = 0; i < arbs.length; i++) {
            if (arbs[i] == null) {
                writer.write("//arb" + i + " was null\n");
                continue;
            }
            StringBuffer sb = new StringBuffer("arbitrary");
            sb.append((i+1));
            UIComponent parent = arbs[i].getParent();
            while (parent != null) {
                sb.insert(0, ':');
                sb.insert(0, parent.getId());
                parent = parent.getParent();
            }
            writer.write("//" + sb + "\n");
        }
         **/
    }
    
/*
    private UIComponent find(UIComponent base, String id) {
        if (id.equals(base.getId())) {
            return base;
        }
        UIComponent result = null;
        for (Iterator i = base.getFacetsAndChildren(); i.hasNext(); ) {
            UIComponent kid = (UIComponent) i.next();
            result = find(kid, id);
            if (result != null) {
                break;
            }
        }
        return result;
    }
 **/
    
    private String getAttr(FacesContext context, UIComponent comp, String name) {
        String result = null;
        ValueExpression ve;
        if (null != (ve = comp.getValueExpression(name))) {
            result = (String) ve.getValue(context.getELContext());
        }
        if (result == null) {
            Object value = comp.getAttributes().get(name);
            if (value != null) {
                result = value.toString();
            }
        }
        return result;
    }

    /**
     * Render the ending of the specified UIComponent to the output stream or
     * writer associated with the response we are creating.
     *
     * @param context FacesContext for the current request.
     * @param component UIComponent to be rendered.
     *
     * @exception IOException if an input/output error occurs.
     * @exception NullPointerException if context or component is null.
     */
    public void encodeEnd(FacesContext context, UIComponent component)
            throws IOException {
        if (context == null || component == null) {
            throw new NullPointerException();
        }
        
        if (Beans.isDesignTime() || !component.isRendered() || AsyncResponse.isAjaxRequest()) {
            return;
        }
        
        AjaxTransaction currentTx = (AjaxTransaction)component;
        if (!isLastAjaxTransaction(context, currentTx)) {
            return;
        }

        //create the holders
        List<AjaxTransaction> allTransactionList = currentTx.getAllTransactionList();
        List<ClientIdSubsetHolder> holders = new ArrayList<ClientIdSubsetHolder>();
        for (AjaxTransaction tx : allTransactionList) {
            holders.add(new ClientIdSubsetHolder(tx.getInputs(), tx.getExecute(), tx.getRender()));
        }
        
        //populate the holders
        UIViewRoot viewRoot = context.getViewRoot();
        String precedingIds = "";   //NOI18N
        populateSubsetHolders(context, precedingIds, viewRoot, holders, null, null);
        
        //render all AjaxTransactions
        String[] txIdProps = {"inputs", "execute", "render"};
        String[] txProps = {"asynchronous", "immediate", "methodName", "closure", "xjson", "replaceElement", "postReplace"};
        boolean[] useQuotes = {false, false, true, false, false, true, true};
        StringBuffer sb = new StringBuffer("\n");   //NOI18N
        
        for (int i = 0; i < holders.size(); i++) {
            AjaxTransaction tx = allTransactionList.get(i);
            ClientIdSubsetHolder holder = holders.get(i);
            sb.append("DynaFaces.Tx.config['"); //NOI18N
            sb.append(tx.getId());
            sb.append("'] = {");    //NOI18N
            
            boolean wroteAProp = false;
            for (int p = 0; p < txProps.length; p++) {
                String propValue;
                propValue = getAttr(context, tx, txProps[p]);
                if ( (p == 0 && String.valueOf(true).equals(propValue)) ||
                        (p == 1 && String.valueOf(false).equals(propValue)) ) {
                    propValue = null;
                }
                if (propValue != null && propValue.length() > 0) {
                    if (wroteAProp) {
                        sb.append(", ");    //NOI18N
                    }
                    sb.append(txProps[p]);
                    sb.append(": ");    //NOI18N
                    if (useQuotes[p]) {
                        sb.append('\'');
                    }
                    sb.append(propValue);
                    if (useQuotes[p]) {
                        sb.append('\'');
                    }
                    wroteAProp = true;
                }
            }
            
            sb.append("};\n");    //NOI18N
            
            String inputsPropValue = null;
            for (int p = 0; p < txIdProps.length; p++) {
                String propValue;
                switch (p) {
                    case 0: 
                        propValue = holder.getInputClientIdString(); 
                        inputsPropValue = propValue;
                        break;
                    case 1: 
                        propValue = holder.getExecuteClientIdString(); 
                        if (propValue == null || propValue.length() == 0) {
                            propValue = inputsPropValue;
                        }
                        break;
                    case 2: 
                        propValue = holder.getRenderClientIdString();
                        break;
                    default: throw new RuntimeException();
                }
                if (propValue != null && propValue.length() > 0) {
                    sb.append("DynaFaces.Tx.config['"); //NOI18N
                    sb.append(tx.getId());
                    sb.append("'].");    //NOI18N
                    sb.append(txIdProps[p]);
                    sb.append(" = "); //NOI18N
                    sb.append(propValue);
                    sb.append(";\n");    //NOI18N
                }
            }
            //render DynaFaces.Tx.fireXxx = function(sourceElement, defaultBehavior) {DynaFaces.Tx.fire('xxx');}
            if (tx.getId().length() > 0) {
                sb.append("DynaFaces.Tx.fire");    //NOI18N
                String firstLetterUpper = tx.getId().substring(0, 1).toUpperCase();
                sb.append(firstLetterUpper);
                if (tx.getId().length() > 1) {
                    String remainder = tx.getId().substring(1);
                    sb.append(remainder);
                }
                sb.append(" = function(sourceElement, defaultBehavior) {\n");    //NOI18N
                sb.append("    DynaFaces.Tx._fire('");   //NOI18N
                sb.append(tx.getId());
                sb.append("', sourceElement, defaultBehavior);\n}\n");    //NOI18N
            }
        }
        ResponseWriter writer = context.getResponseWriter();
        writer.startElement("script", component);   //NOI1I8N
        writer.write(sb.toString());
        writer.endElement("script");   //NOI1I8N
    }

    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    // Private methods and classes
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    //walk down the tree. for each component, compare its fqServerId to the inputIds, executeIds, and renderIds in all holders.
    //wherever there is a match, add the component's clientId to the holder's corresponding xxxClientIds List[].
    private void populateSubsetHolders(FacesContext context, String precedingIds, UIComponent parent, List<ClientIdSubsetHolder> holders, 
            Object[] contextualTables, Object[] contextualRows) {
        Iterator kids = parent.getFacetsAndChildren();
        while (kids.hasNext()) {
            UIComponent kid = (UIComponent)kids.next();
            String kidFqServerId = precedingIds + NamingContainer.SEPARATOR_CHAR + kid.getId();
            populateClientIdAllHolders(context, kidFqServerId, kid, holders);
            
            //recurse
            if (kid instanceof UIData) {
                UIData kidTable = (UIData)kid;
                int originalRowIndex = kidTable.getRowIndex();
                int rowIndex = 0;
                kidTable.setRowIndex(rowIndex);
                while(kidTable.isRowAvailable()){
                    Object[] localContextualTables = appendToArray(contextualTables, kidTable);
                    Object[] localContextualRows = appendToArray(contextualRows, new Integer(rowIndex));
                    populateSubsetHolders(context, kidFqServerId, kidTable, holders, localContextualTables, localContextualRows);
                    kidTable.setRowIndex(++rowIndex);
                }
                kidTable.setRowIndex(originalRowIndex);
            } 
            /* can't check for TableRowGroup unless I include the webui-jsf.jar in lib
            else if (kid instanceof TableRowGroup) {
                TableRowGroup group = (TableRowGroup) kid;
                RowKey[] rowKeys = group.getRowKeys();
                RowKey oldRowKey = group.getRowKey(); // Save RowKey.

                // Check for null TableDataProvider.
                if (rowKeys != null) {
                    for (int i = 0; i < rowKeys.length; i++) {
                        group.setRowKey(rowKeys[i]);
                        if (!group.isRowAvailable()) {
                            continue;
                        }
                        Object[] localContextualTables = appendToArray(contextualTables, group);
                        Object[] localContextualRows = appendToArray(contextualRows, rowKeys[i]);
                        populateSubsetHolders(kidFqServerId, group, holders, localContextualTables, localContextualRows);
                    }
                }
                group.setRowKey(oldRowKey); // Restore RowKey.
            } 
             **/
            else {
                populateSubsetHolders(context, kidFqServerId, kid, holders, contextualTables, contextualRows);
            }
        }
    }
    
    private void populateClientIdAllHolders(FacesContext context, String fqServerId, UIComponent component, List<ClientIdSubsetHolder> holders) {
        for (ClientIdSubsetHolder holder : holders) {
            holder.populateClientId(context, fqServerId, component);
        }
    }
    
    private static Object[] appendToArray(Object[] array, Object item) {
        Object[] result;
        if (array == null) {
            result = new Object[]{item};
        }
        else {
            result = new Object[array.length + 1];
            System.arraycopy(array, 0, result, 0, array.length);
            result[array.length] = item;
        }
        return result;
    }
    
    private boolean isLastAjaxTransaction(FacesContext context,
            AjaxTransaction currentTransaction) {
        boolean result = false;
        List<AjaxTransaction> allTransactionList = currentTransaction.getAllTransactionList();
        if (null != allTransactionList && !allTransactionList.isEmpty()) {
            AjaxTransaction lastRenderedTransaction = null;
            // Find the last entry in the allTransactionList
            // that has its rendered property set to true
            for (int i = allTransactionList.size() - 1; i >= 0; i--) {
                AjaxTransaction aTx = allTransactionList.get(i);
                if (aTx.isRendered()) {
                    lastRenderedTransaction = aTx;
                    break;
                }
            }
            if (null != lastRenderedTransaction) {
                result = (currentTransaction == lastRenderedTransaction);
            }
        }
        return result;
    }

    private transient XhtmlHelper xHtmlHelper = null;
    
    private XhtmlHelper getXhtmlHelper() {
        if (null == xHtmlHelper) {
            xHtmlHelper = new XhtmlHelper();
        }
        return xHtmlHelper;
    }
    
    private class ClientIdSubsetHolder extends AjaxTransaction.SubsetHolder {
        //each is an array of List<String>
        private List[] inputClientIds;
        private List[] executeClientIds;
        private List[] renderClientIds;
        
        public ClientIdSubsetHolder(String inputs, String execute, String render) {
            super(inputs, execute, render);
            String[] inputIds = this.getInputIds();
            String[] executeIds = this.getExecuteIds();
            String[] renderIds = this.getRenderIds();
            this.inputClientIds = initClientIds(inputIds);
            this.executeClientIds = initClientIds(executeIds);
            this.renderClientIds = initClientIds(renderIds);
        }
        
        public void populateClientId(FacesContext context, String fqServerId, UIComponent component) {
            String[] inputIds = this.getInputIds();
            String[] executeIds = this.getExecuteIds();
            String[] renderIds = this.getRenderIds();
            populateClientIdInternal(context, fqServerId, component, inputIds, this.inputClientIds);
            populateClientIdInternal(context, fqServerId, component, executeIds, this.executeClientIds);
            populateClientIdInternal(context, fqServerId, component, renderIds, this.renderClientIds);
        }
        
        public String getInputClientIdString() {
            return getClientIdString(this.inputClientIds);
        }
        
        public String getExecuteClientIdString() {
            return getClientIdString(this.executeClientIds);
        }
        
        public String getRenderClientIdString() {
            return getClientIdString(this.renderClientIds);
        }
        
        private String getClientIdString(List[] clientIds) {
            if (clientIds == null) {
                return null;
            }
            StringBuffer sb = new StringBuffer();
            sb.append('[');
            boolean wroteAnId = false;
            for (int i = 0; i < clientIds.length; i++) {
                List<String> list = (List<String>)clientIds[i];
                for (String clientId : list) {
                    if (wroteAnId) {
                        sb.append(',');
                    }
                    sb.append("'"); //NOI18N
                    sb.append(clientId);
                    sb.append("'"); //NOI18N
                    wroteAnId = true;
                }
            }
            sb.append(']');
            return sb.toString();
        }
        
        private void populateClientIdInternal(FacesContext context, String fqServerId, UIComponent component, 
                String[] serverIds, List[] clientIds) {
            if (serverIds == null || AjaxTransaction.ALL.equals(serverIds[0]) || AjaxTransaction.NONE.equals(serverIds[0])) {
                return;
            }
            for (int i = 0; i < serverIds.length; i++) {
                if (fqServerId.endsWith(serverIds[i])) {
                    clientIds[i].add(component.getClientId(context));
                    //don't return here, just in case there are logical duplicate entries in serverIds
                }
            }
        }
        
        private List[] initClientIds(String[] serverIds) {
            if (serverIds == null) {
                return null;
            }
            List[] listArray = new List[serverIds.length];
            for (int i = 0; i < serverIds.length; i++) {
                listArray[i] = new ArrayList<String>();
            }
            if (AjaxTransaction.ALL.equals(serverIds[0]) || AjaxTransaction.NONE.equals(serverIds[0])) {
                listArray[0].add(serverIds[0]);
            }
            return listArray;
        }
    }

}

package com.sun.faces.extensions.avatar.taglib;

import com.sun.faces.extensions.avatar.components.AjaxTransaction;
import javax.el.ValueExpression;
import javax.faces.component.UIComponent;
import javax.faces.webapp.UIComponentELTag;

public class AjaxTransactionTag extends UIComponentELTag {
    /** 
     * <p>Return the requested component type.</p> 
     */ 
    public String getComponentType() { 
        return "com.sun.faces.AjaxTransaction"; 
    } 
 
    /** 
     * <p>Return the requested renderer type.</p> 
     */ 
    public String getRendererType() { 
        return "com.sun.faces.AjaxTransaction"; 
    }
    
    /** 
     * <p>Set the properties of the supplied component.</p> 
     */ 
    protected void setProperties(UIComponent comp) {
        super.setProperties(comp);
        
        AjaxTransaction component = (AjaxTransaction) comp;
        
        if (asynchronous != null) {
            if (!asynchronous.isLiteralText()) {
                component.setValueExpression("asynchronous", asynchronous);
            } else {
                component.setAsynchronous(java.lang.Boolean.valueOf(asynchronous.getExpressionString()).booleanValue());
            }
        }
        
        if (immediate != null) {
            if (!immediate.isLiteralText()) {
                component.setValueExpression("immediate", immediate);
            } else {
                component.setImmediate(java.lang.Boolean.valueOf(immediate.getExpressionString()).booleanValue());
            }
        }
        
        if (null != methodName) {
            if (methodName.isLiteralText()) {
                component.getAttributes().put("methodName", methodName.getValue(getFacesContext().getELContext()));
            }
            else {
                component.setValueExpression("methodName", methodName);
            }
        }
        if (null != closure) {
            if (closure.isLiteralText()) {
                component.getAttributes().put("closure", closure.getValue(getFacesContext().getELContext()));
            }
            else {
                component.setValueExpression("closure", closure);
            }
        }
        if (null != xjson) {
            if (xjson.isLiteralText()) {
                component.getAttributes().put("xjson", xjson.getValue(getFacesContext().getELContext()));
            }
            else {
                component.setValueExpression("xjson", xjson);
            }
        }
        if (null != replaceElement) {
            if (replaceElement.isLiteralText()) {
                component.getAttributes().put("replaceElement", replaceElement.getValue(getFacesContext().getELContext()));
            }
            else {
                component.setValueExpression("replaceElement", replaceElement);
            }
        }
        if (null != postReplace) {
            if (postReplace.isLiteralText()) {
                component.getAttributes().put("postReplace", postReplace.getValue(getFacesContext().getELContext()));
            }
            else {
                component.setValueExpression("postReplace", postReplace);
            }
        }
        if (null != inputs) {
            if (inputs.isLiteralText()) {
                component.getAttributes().put("inputs", inputs.getValue(getFacesContext().getELContext()));
            }
            else {
                component.setValueExpression("inputs", inputs);
            }
        }
        if (null != execute) {
            if (execute.isLiteralText()) {
                component.getAttributes().put("execute", execute.getValue(getFacesContext().getELContext()));
            }
            else {
                component.setValueExpression("execute", execute);
            }
        }
        if (null != render) {
            if (render.isLiteralText()) {
                component.getAttributes().put("render", render.getValue(getFacesContext().getELContext()));
            }
            else {
                component.setValueExpression("render", render);
            }
        }
    }

    /**
     * Holds value of property asynchronous.
     */
    private ValueExpression asynchronous;

    /**
     * Setter for property asynchronous.
     * @param asynchronous New value of property asynchronous.
     */
    public void setAsynchronous(ValueExpression asynchronous) {
        this.asynchronous = asynchronous;
    }

    /**
     * Holds value of property immediate.
     */
    private ValueExpression immediate;

    /**
     * Setter for property immediate.
     * @param immediate New value of property immediate.
     */
    public void setImmediate(ValueExpression immediate) {
        this.immediate = immediate;
    }

    /**
     * Holds value of property methodName.
     */
    private ValueExpression methodName;

    /**
     * Setter for property methodName.
     * @param methodName New value of property methodName.
     */
    public void setMethodName(ValueExpression methodName) {
        this.methodName = methodName;
    }

    /**
     * Holds value of property closure.
     */
    private ValueExpression closure;

    /**
     * Setter for property closure.
     * @param closure New value of property closure.
     */
    public void setClosure(ValueExpression closure) {
        this.closure = closure;
    }

    /**
     * Holds value of property xjson.
     */
    private ValueExpression xjson;

    /**
     * Setter for property xjson.
     * @param xjson New value of property xjson.
     */
    public void setXjson(ValueExpression xjson) {
        this.xjson = xjson;
    }

    /**
     * Holds value of property replaceElement.
     */
    private ValueExpression replaceElement;

    /**
     * Setter for property replaceElement.
     * @param replaceElement New value of property replaceElement.
     */
    public void setReplaceElement(ValueExpression replaceElement) {
        this.replaceElement = replaceElement;
    }
    
    /**
     * Holds value of property postReplace.
     */
    private ValueExpression postReplace;

    /**
     * Setter for property postReplace.
     * @param postReplace New value of property postReplace.
     */
    public void setPostReplace(ValueExpression postReplace) {
        this.postReplace = postReplace;
    }

    /**
     * Holds value of property inputs.
     */
    private ValueExpression inputs;

    /**
     * Setter for property inputs.
     * @param inputs New value of property inputs.
     */
    public void setInputs(ValueExpression inputs) {
        this.inputs = inputs;
    }

    /**
     * Holds value of property execute.
     */
    private ValueExpression execute;
    
    /**
     * Setter for property execute.
     * @param execute New value of property execute.
     */
    public void setExecute(ValueExpression execute) {
        this.execute = execute;
    }

    /**
     * Holds value of property render.
     */
    private ValueExpression render;

    /**
     * Setter for property render.
     * @param render New value of property render.
     */
    public void setRender(ValueExpression render) {
        this.render = render;
    }
    
    
}

package com.sun.faces.extensions.avatar.components;

import com.sun.faces.extensions.avatar.lifecycle.AsyncResponse;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.faces.context.FacesContext;
import javax.el.ValueExpression;
import javax.faces.component.UIComponentBase;

/**
 * <p>Component that lets you configure an Ajax transaction that can be
 * initiated within client-side script. Renders client-side script that invokes
 * <code>DynaFaces.fireAjaxTransaction</code> with appropriate paramters.</p>
 */
public class AjaxTransaction extends UIComponentBase {
    
    private static final String ALL_TRANSACTION_LIST = AsyncResponse.FACES_PREFIX + "ALL_AJAX_TRANSACTION_LIST";
    public static final String ALL = "all"; //NOI18N
    public static final String NONE = "none"; //NOI18N
    
    /**
     * <p>Request attribute that indicates a <code>script</code> tag pointing to com_sun_faces_ajax_tx.js has been rendered already.</p>
     */
    public static final String TX_JS_LINKED = "com.sun.faces.extensions.avatar.LINKED/com_sun_faces_ajax_tx.js";
    
    public AjaxTransaction() {
        super();
        setRendererType("com.sun.faces.AjaxTransaction");
    }

    /** 
     * <p>Return the family for this component.</p> 
     */ 
    public String getFamily() { 
        return "com.sun.faces.AjaxTransaction"; 
    }
    
    public void setId(String id) {
        super.setId(id);
        addThisToTransactionList();
        
    }
    
    private void addThisToTransactionList() {
        List<AjaxTransaction> transactionList = getAllTransactionList();
        if (!transactionList.contains(this)) {
            transactionList.add(this);
        }
    }
    
    public List<AjaxTransaction> getAllTransactionList() {
        Map<String,Object> requestMap = FacesContext.getCurrentInstance().getExternalContext().getRequestMap();
        List<AjaxTransaction> transactionList = (List<AjaxTransaction>) requestMap.get(ALL_TRANSACTION_LIST);
        if (null == transactionList) {
            transactionList = new ArrayList<AjaxTransaction>();
            requestMap.put(ALL_TRANSACTION_LIST, transactionList);
        }

        return transactionList;
    }
    
    /**
     * <p>A boolean value indicating whether the Ajax request will be 
     * made asynchronously. True by default.</p>
     */
    private boolean asynchronous = true;
    
    /**
     * <p>Get a boolean value indicating whether the ajax request will be 
     * made asynchronously. True by default.</p>
     */
    public boolean isAsynchronous() {
        return this.asynchronous;
    }
    
    /**
     * <p>Set a boolean value indicating whether the ajax request will be 
     * made asynchronously.</p>
     * @see #isAsynchronous()
     */
    public void setAsynchronous(boolean asynchronous) {
        this.asynchronous = asynchronous;
    }
    
    /**
     * <p>Whether the immediate attribute will be set to true, for this request 
     * only, on any input or command components that are encountered during the 
     * partial traversal as specified in the execute or render options.</p>
     */
    private boolean immediate;
    
    /**
     * <p>Get whether the immediate attribute will be set to true, for this request 
     * only, on any input or command components that are encountered during the 
     * partial traversal as specified in the execute or render options.</p>
     */
    public boolean isImmediate() {
        return this.immediate;
    }
    
    /**
     * <p>Set whether the immediate attribute will be set to true, for this request 
     * only, on any input or command components that are encountered during the 
     * partial traversal as specified in the execute or render options.</p>
     * @see #isImmediate()
     */
    public void setImmediate(boolean immediate) {
        this.immediate = immediate;
    }

    /**
     * <p>The name of a JavaScript function to be called after
     * the new content from the server for this zone has been
     * installed into the view.</p>
     */
    private String postReplace = null;

    /**
     * <p>Get the name of a JavaScript function to be called after
     * the new content from the server for this zone has been
     * installed into the view.</p>
     */
    public String getPostReplace() {
        if (this.postReplace != null) {
            return this.postReplace;
        }
        ValueExpression ve = getValueExpression("postReplace");
        if (ve != null) {
            return (String) ve.getValue(getFacesContext().getELContext());
        }
        return null;
    }

    /**
     * <p>Set the name of a JavaScript function to be called after
     * the new content from the server for this zone has been
     * installed into the view.</p>
     * @see #getPostReplace()
     */
    public void setPostReplace(String postReplace) {
        this.postReplace = postReplace;
    }
    
    /**
     * <p>The name of a JavaScript function
     * that will be called when the system needs to replace a chunk
     * of markup in the view based on the return from the server.</p>
     */
    private String replaceElement = null;

    /**
     * <p>Get the name of a JavaScript function
     * that will be called when the system needs to replace a chunk
     * of markup in the view based on the return from the server.</p>
     */
    public String getReplaceElement() {
        if (this.replaceElement != null) {
            return this.replaceElement;
        }
        ValueExpression ve = getValueExpression("replaceElement");
        if (ve != null) {
            return (String) ve.getValue(getFacesContext().getELContext());
        }
        return null;
    }

    /**
     * <p>Set the name of a JavaScript function
     * that will be called when the system needs to replace a chunk
     * of markup in the view based on the return from the server.</p>
     * @see #getReplaceElement()
     */
    public void setReplaceElement(String replaceElement) {
        this.replaceElement = replaceElement;
    }
    
    /**
     * <p>Arbitrary script that obtains or specifies a closure that is kept 
     * locally and passed to the <code>replaceElement</code> or 
     * <code>postReplace</code> functions. It can be a function invocation 
     * that returns the closure or a reference to the closure itself.</p>
     */
    private String closure = null;

    /**
     * <p>Get arbitrary script that obtains or specifies a closure that is kept 
     * locally and passed to the <code>replaceElement</code> or 
     * <code>postReplace</code> functions. It can be a function invocation 
     * that returns the closure or a reference to the closure itself.</p>
     */
    public String getClosure() {
        if (this.closure != null) {
            return this.closure;
        }
        ValueExpression ve = getValueExpression("closure");
        if (ve != null) {
            return (String) ve.getValue(getFacesContext().getELContext());
        }
        return null;
    }

    /**
     * <p>Set arbitrary script that obtains or specifies a closure that is kept 
     * locally and passed to the <code>replaceElement</code> or 
     * <code>postReplace</code> functions. It can be a function invocation 
     * that returns the closure or a reference to the closure itself.</p>
     * @see #getClosure()
     */
    public void setClosure(String closure) {
        this.closure = closure;
    }
    
    /**
     * <p>A JavaScript associative array object that will be sent up to the 
     * server in the X-JSON header. This value may be operated on by the server.
     * The possibly modified value will be returned to the client as the last 
     * argument in the <code>replaceElement</code> or <code>postReplace</code>
     * functions.</p>
     */
    private String xjson = null;

    /**
     * <p>Get a JavaScript associative array object that will be sent up to the 
     * server in the X-JSON header. This value may be operated on by the server.
     * The possibly modified value will be returned to the client as the last 
     * argument in the <code>replaceElement</code> or <code>postReplace</code>
     * functions.</p>
     */
    public String getXjson() {
        if (this.xjson != null) {
            return this.xjson;
        }
        ValueExpression ve = getValueExpression("xjson");
        if (ve != null) {
            return (String) ve.getValue(getFacesContext().getELContext());
        }
        return null;
    }

    /**
     * <p>Set a JavaScript associative array object that will be sent up to the 
     * server in the X-JSON header. This value may be operated on by the server.
     * The possibly modified value will be returned to the client as the last 
     * argument in the <code>replaceElement</code> or <code>postReplace</code>
     * functions.</p>
     * @see #getXjson()
     */
    public void setXjson(String xjson) {
        this.xjson = xjson;
    }
    
    /**
     * <p>Information about a server-side method to invoke. 
     * If specified, must be the only option, and must conform to the syntax 
     * <code>|CLIENT_ID|,|METHOD_NAME|,[phaseId]</code>, 
     * where <code>|CLIENT_ID|</code> is the client id of the component to be 
     * the source of the event, <code>|METHOD_NAME|</code> is the name of a 
     * method on the component named by <code>|CLIENT_ID|</code>, and the 
     * optional phaseId indicates the lifecycle phase in which this method 
     * expression should be invoked. Given the <code>|METHOD_NAME|</code>, the 
     * renderer for the component, if any, is consulted for for a matching 
     * method with the signature 
     * <code>public void methodName(FacesContext c)</code>. If found, that 
     * method is used. If not, the component is consulted for a matching 
     * method with the signature 
     * <code>public void methodName(FacesContext c)</code>; if found, that 
     * method is used. Otherwise an exception is thrown.</p>
     */
    private String methodName = null;

    /**
     * <p>Get information about a server-side method to invoke. 
     * If specified, must be the only option, and must conform to the syntax 
     * <code>|CLIENT_ID|,|METHOD_NAME|,[phaseId]</code>, 
     * where <code>|CLIENT_ID|</code> is the client id of the component to be 
     * the source of the event, <code>|METHOD_NAME|</code> is the name of a 
     * method on the component named by <code>|CLIENT_ID|</code>, and the 
     * optional phaseId indicates the lifecycle phase in which this method 
     * expression should be invoked. Given the <code>|METHOD_NAME|</code>, the 
     * renderer for the component, if any, is consulted for for a matching 
     * method with the signature 
     * <code>public void methodName(FacesContext c)</code>. If found, that 
     * method is used. If not, the component is consulted for a matching 
     * method with the signature 
     * <code>public void methodName(FacesContext c)</code>; if found, that 
     * method is used. Otherwise an exception is thrown.</p>
     */
    public String getMethodName() {
        if (this.methodName != null) {
            return this.methodName;
        }
        ValueExpression ve = getValueExpression("methodName");
        if (ve != null) {
            return (String) ve.getValue(getFacesContext().getELContext());
        }
        return null;
    }

    /**
     * <p>Set information about a server-side method to invoke. 
     * If specified, must be the only option, and must conform to the syntax 
     * <code>|CLIENT_ID|,|METHOD_NAME|,[phaseId]</code>, 
     * where <code>|CLIENT_ID|</code> is the client id of the component to be 
     * the source of the event, <code>|METHOD_NAME|</code> is the name of a 
     * method on the component named by <code>|CLIENT_ID|</code>, and the 
     * optional phaseId indicates the lifecycle phase in which this method 
     * expression should be invoked. Given the <code>|METHOD_NAME|</code>, the 
     * renderer for the component, if any, is consulted for for a matching 
     * method with the signature 
     * <code>public void methodName(FacesContext c)</code>. If found, that 
     * method is used. If not, the component is consulted for a matching 
     * method with the signature 
     * <code>public void methodName(FacesContext c)</code>; if found, that 
     * method is used. Otherwise an exception is thrown.</p>
     * @see #getMethodName()
     */
    public void setMethodName(String methodName) {
        this.methodName = methodName;
    }
    
    /**
     * <p>A comma separated string containing a list of qualified component ids
     * (not client ids) specifying inputs that will be sent to the server via 
     * an Ajax request. From this list, a corresponding list of client ids will 
     * be rendered.</p>
     */
    private String inputs = null;

    /**
     * <p>Get a comma separated string containing a list of qualified component ids
     * (not client ids) specifying inputs that will be sent to the server via 
     * an Ajax request. From this list, a corresponding list of client ids will 
     * be rendered.</p>
     */
    public String getInputs() {
        if (this.inputs != null) {
            return this.inputs;
        }
        ValueExpression ve = getValueExpression("inputs");
        if (ve != null) {
            return (String) ve.getValue(getFacesContext().getELContext());
        }
        return null;
    }

    /**
     * <p>Set a comma separated string containing a list of qualified component ids
     * (not client ids) specifying inputs that will be sent to the server via 
     * an Ajax request. From this list, a corresponding list of client ids will 
     * be rendered.</p>
     * @see #getInputs()
     */
    public void setInputs(String inputs) {
        this.inputs = inputs;
    }
    
    /**
     * <p>A comma separated string containing a list of qualified component ids
     * (not client ids) against which the execute portion of the request 
     * processing lifecycle must be run. From this list, a corresponding list 
     * of client ids will be rendered.</p>
     */
    private String execute = null;

    /**
     * <p>Get a comma separated string containing a list of qualified component ids
     * (not client ids) against which the execute portion of the request 
     * processing lifecycle must be run. From this list, a corresponding list 
     * of client ids will be rendered.</p>
     */
    public String getExecute() {
        if (this.execute != null) {
            return this.execute;
        }
        ValueExpression ve = getValueExpression("execute");
        if (ve != null) {
            return (String) ve.getValue(getFacesContext().getELContext());
        }
        return null;
    }

    /**
     * <p>Set a comma separated string containing a list of qualified component ids
     * (not client ids) against which the execute portion of the request 
     * processing lifecycle must be run. From this list, a corresponding list 
     * of client ids will be rendered.</p>
     * @see #getExecute()
     */
    public void setExecute(String execute) {
        this.execute = execute;
    }
    
    /**
     * <p>A comma separated string containing a list of qualified component ids 
     * (not client ids) for which the "render" portion of the request 
     * processing lifecycle will be run. From this list, a corresponding list 
     * of client ids will be rendered.</p>
     */
    private String render = null;

    /**
     * <p>Get a comma separated string containing a list of qualified component ids 
     * (not client ids) for which the "render" portion of the request 
     * processing lifecycle will be run. From this list, a corresponding list 
     * of client ids will be rendered.</p>
     */
    public String getRender() {
        if (this.render != null) {
            return this.render;
        }
        ValueExpression ve = getValueExpression("render");
        if (ve != null) {
            return (String) ve.getValue(getFacesContext().getELContext());
        }
        return null;
    }

    /**
     * <p>Set a comma separated string containing a list of qualified component ids 
     * (not client ids) for which the "render" portion of the request 
     * processing lifecycle will be run. From this list, a corresponding list 
     * of client ids will be rendered.</p>
     * @see #getRender()
     */
    public void setRender(String render) {
        this.render = render;
    }
    
    /**
     * <p>Restore the state of this component.</p>
     */
    public void restoreState(FacesContext context, Object state) {
        Object values[] = (Object[]) state;
        super.restoreState(context, values[0]);
        this.asynchronous = ((Boolean) values[1]).booleanValue();
        this.immediate = ((Boolean) values[2]).booleanValue();
        this.methodName = (String) values[3];
        this.closure = (String) values[4];
        this.xjson = (String) values[5];
        this.replaceElement = (String) values[6];
        this.postReplace = (String) values[7];
        this.inputs = (String) values[8];
        this.execute = (String) values[9];
        this.render = (String) values[10];
    }

    /**
     * <p>Save the state of this component.</p>
     */
    public Object saveState(FacesContext context) {
        Object values[] = new Object[11];
        values[0] = super.saveState(context);
        values[1] = Boolean.valueOf(this.asynchronous);
        values[2] = Boolean.valueOf(this.immediate);
        values[3] = this.methodName;
        values[4] = this.closure;
        values[5] = this.xjson;
        values[6] = this.replaceElement;
        values[7] = this.postReplace;
        values[8] = this.inputs;
        values[9] = this.execute;
        values[10] = this.render;
        return values;
    }
    
    public static class SubsetHolder {
        protected String[] inputIds;
        protected String[] executeIds;
        protected String[] renderIds;
        
        public SubsetHolder(String inputs, String execute, String render) {
            this.inputIds = splitAndReduce(inputs);
            this.executeIds = splitAndReduce(execute);
            this.renderIds = splitAndReduce(render);
        }
        
        public String[] getInputIds() {
            return this.inputIds;
        }
        
        public String[] getExecuteIds() {
            return this.executeIds;
        }
        
        public String[] getRenderIds() {
            return this.renderIds;
        }
        
        private String[] splitAndReduce(String idStr) {
            if (idStr == null) {
                return null;
            }
            idStr = idStr.trim();
            String[] ids = idStr.split("\\s*,\\s*");
            if (ids.length == 0) {
                return null;
            }
            Set<String> set = new HashSet<String>();
            List<String> list = new ArrayList<String>();
            for (int i = 0; i < ids.length; i++) {
                ids[i] = ids[i].trim();
                if (ids[i].length() == 0) {
                    continue;
                }
                if (ALL.equals(ids[i]) || NONE.equals(ids[i])) {
                    if (ids.length == 1) {
                        return ids;
                    }
                    else {
                        return new String[]{ids[i]};
                    }
                }
                if (!set.contains(ids[i])) {
                    list.add(ids[i]);
                    set.add(ids[i]);
                }
            }
            if (list.size() == 0) {
                return null;
            }
            return list.toArray(new String[list.size()]);
        }
    }
    
}
